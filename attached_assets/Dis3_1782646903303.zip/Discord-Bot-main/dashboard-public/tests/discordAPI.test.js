'use strict';

const discordAPI = require('../utils/discordAPI');

describe('Discord API memory guards', () => {
    test('reports bounded request/response diagnostics', () => {
        const diag = discordAPI.getDiscordApiDiagnostics();

        expect(diag).toHaveProperty('total');
        expect(diag).toHaveProperty('inFlight');
        expect(diag).toHaveProperty('responseTooLarge');
        expect(diag).toHaveProperty('requestBodyTooLarge');
        expect(diag).toHaveProperty('responseMaxBytes');
        expect(diag).toHaveProperty('bodyMaxBytes');
        expect(diag).toHaveProperty('roleMax');
        expect(diag).toHaveProperty('channelMax');
        expect(diag).toHaveProperty('permissionOverwriteMax');
        expect(diag.responseMaxBytes).toBeGreaterThan(0);
        expect(diag.bodyMaxBytes).toBeGreaterThan(0);
        expect(diag.roleMax).toBeGreaterThan(0);
        expect(diag.channelMax).toBeGreaterThan(0);
        expect(diag.permissionOverwriteMax).toBeGreaterThan(0);
    });

    test('rejects oversized request bodies before buffering a network request', async () => {
        const before = discordAPI.getDiscordApiDiagnostics().requestBodyTooLarge;
        const oversizedBody = 'x'.repeat(discordAPI.getDiscordApiDiagnostics().bodyMaxBytes + 1);

        await expect(discordAPI.apiFetch('/users/@me', {
            method: 'POST',
            body: oversizedBody
        })).rejects.toThrow(/request body too large/);

        const after = discordAPI.getDiscordApiDiagnostics().requestBodyTooLarge;
        expect(after).toBeGreaterThan(before);
    });

    test('caps dashboard role and channel normalization payloads', () => {
        const diag = discordAPI.getDiscordApiDiagnostics();
        const roles = Array.from({ length: diag.roleMax + 25 }, (_, idx) => ({
            id: String(10000000000000000n + BigInt(idx)),
            name: `Role ${idx}`,
            position: idx
        }));
        const channels = Array.from({ length: diag.channelMax + 25 }, (_, idx) => ({
            id: String(20000000000000000n + BigInt(idx)),
            name: `Channel ${idx}`,
            type: 0,
            position: idx,
            permission_overwrites: Array.from({ length: diag.permissionOverwriteMax + 10 }, (__, owIdx) => ({
                id: String(30000000000000000n + BigInt(owIdx)),
                type: 0,
                allow: '0',
                deny: '0'
            }))
        }));

        const sortedRoles = discordAPI.sortRolesForDashboard(roles);
        const sortedChannels = discordAPI.sortChannelsForDashboard(channels);

        expect(sortedRoles).toHaveLength(diag.roleMax);
        expect(sortedChannels).toHaveLength(diag.channelMax);
        expect(sortedChannels[0].permissionOverwrites).toHaveLength(diag.permissionOverwriteMax);
    });
});
