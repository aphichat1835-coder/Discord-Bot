const mongoose = require('mongoose');

const mixed = mongoose.Schema.Types.Mixed;

const schema = new mongoose.Schema({
    guildId: { type: String, required: true, index: true },
    userId:  { type: String, required: true, index: true },
    roleId:  String,

    requestId: String,

    result: { type: String, enum: ['success', 'failed', 'blocked'], required: true },
    reason: String,

    riskScore: Number,
    riskFlags: [String],
    oauthScope: String,
    stateMode: String,

    policySnapshot: mixed,
    discordSnapshot: mixed,
    guildSnapshot: mixed,
    memberSnapshot: mixed,
    joinResult: mixed,
    roleAssignResult: mixed,

    trackingSnapshot: {
        ipHash: String,
        firstSeenAt: Number,
        lastSeenAt: Number,
        totalVerifications: Number,
        uniqueUsers: Number,
        maxRiskScore: Number,
        lastRiskScore: Number
    },

    ipInfo: {
        encryptedRawIp: String,
        ipHash: String,

        country: String,
        countryCode: String,
        region: String,
        city: String,
        zip: String,
        lat: Number,
        lon: Number,
        timezone: String,

        isp: String,
        org: String,
        as: String,
        asname: String,
        reverse: String,

        isVPN: Boolean,
        isProxy: Boolean,
        isTOR: Boolean,
        hosting: Boolean,
        mobile: Boolean,

        riskScore: Number,
        riskFlags: [String],

        lookupProvider: String,
        lookupStatus: String,
        lookupMessage: String,
        lookupRaw: mixed,

        // Owner Approved: It is explicitly required and necessary to collect and use raw IP data for auditing and system security.
        ipSource: String,
        headerIps: mixed,
        spoofSuspected: Boolean,
        spoofFlags: [String],
        headerIpConflict: Boolean,

        proxyCheckProvider: String,
        proxyCheckStatus: String,
        proxyCheckRaw: mixed,

        lookupAt: Number
    },

    device: {
        userAgent: String,
        browser: String,
        os: String,
        language: String,
        languages: [String],
        timezone: String,
        platform: String,
        deviceType: String,
        screenSize: String,
        viewportSize: String,
        colorDepth: Number,
        devicePixelRatio: Number,
        touchPoints: Number,
        referrer: String,
        fingerprintHash: String
    },

    deletedAt: Number,
    deletedBy: String,

    createdAt: { type: Number, default: Date.now },
    verifiedAt: { type: Number, default: Date.now }
}, { minimize: false });

schema.index({ guildId: 1, userId: 1 });
schema.index({ guildId: 1, verifiedAt: -1 });
schema.index({ guildId: 1, result: 1, verifiedAt: -1 });
schema.index({ 'ipInfo.ipHash': 1 });
schema.index({ 'device.fingerprintHash': 1 });
schema.index({ riskScore: -1 });
schema.index({ stateMode: 1 });
schema.index({ requestId: 1 });
schema.index({ 'trackingSnapshot.uniqueUsers': -1 });

module.exports =
    mongoose.models.VerifyLog ||
    mongoose.model('VerifyLog', schema);
